from flask import Flask, render_template, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import (
    LoginManager, UserMixin, login_user, login_required,
    logout_user, current_user
)
from datetime import date

app = Flask(__name__)
app.config['SECRET_KEY'] = "pranali"
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///healthhub.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# ----------------------- Models -----------------------

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)  # Plain text (insecure)

class Doctor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    gender = db.Column(db.String(20), nullable=False)
    specialization = db.Column(db.String(150), nullable=False)
    qualification = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(150), nullable=False)
    experience = db.Column(db.String(10), nullable=False)
    available_days = db.Column(db.String(100), nullable=False)
    available_time = db.Column(db.String(100), nullable=False)

class Patient(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    age = db.Column(db.Integer, nullable=False)
    gender = db.Column(db.String(20), nullable=False)
    contact = db.Column(db.String(20))
    visit_date = db.Column(db.String(20), nullable=False)
    disease = db.Column(db.String(150), nullable=False)
    appointments = db.relationship('Appointment', backref='patient', cascade="all, delete-orphan", lazy=True)

class Appointment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    patient_id = db.Column(db.Integer, db.ForeignKey('patient.id'), nullable=False)
    doctor_id = db.Column(db.Integer, db.ForeignKey('doctor.id'), nullable=False)
    date = db.Column(db.String(20), nullable=False)
    time = db.Column(db.String(10), nullable=False)
    doctor = db.relationship('Doctor', backref=db.backref('appointments', lazy=True))

# ----------------------- Authentication -----------------------

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']
        confirm_password = request.form['confirm_password']

        if password != confirm_password:
            flash("Passwords do not match.", "danger")
            return redirect(url_for('register'))

        if User.query.filter_by(username=username).first():
            flash("Username already exists.", "warning")
            return redirect(url_for('register'))

        new_user = User(username=username, password=password)
        db.session.add(new_user)
        db.session.commit()
        flash("Registration successful!", "success")
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username'].strip()
        password = request.form['password']

        user = User.query.filter_by(username=username).first()
        if user and user.password == password:
            login_user(user)
            flash("Logged in successfully.", "success")
            return redirect(url_for('dashboard'))
        else:
            flash("Invalid username or password.", "danger")

    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash("Logged out successfully.", "info")
    return redirect(url_for('login'))


@app.route('/')
@login_required
def dashboard():
    total_patients = Patient.query.count()
    total_doctors = Doctor.query.count()
    today = str(date.today())
    todays_patients = Patient.query.filter(Patient.visit_date==today).count()
    doctors = Doctor.query.all()
    patients = Patient.query.all()

    return render_template('dashboard.html',
                           total_patients=total_patients,
                           todays_patients=todays_patients,
                           total_doctors=total_doctors,
                           doctors=doctors,
                           patients=patients)

# ----------------------- Patient Routes -----------------------

@app.route('/add_patient', methods=['GET', 'POST'])
@login_required
def add_patient():
    doctors = Doctor.query.all()

    if request.method == 'POST':
        try:
            name = request.form['name']
            age = int(request.form['age'])
            gender = request.form['gender']
            contact = request.form['contact']
            visit_date = request.form['visit_date']
            disease = request.form['disease']

            # Create new patient
            new_patient = Patient(
                name=name,
                age=age,
                gender=gender,
                contact=contact,
                visit_date=visit_date,
                disease=disease
            )
            db.session.add(new_patient)
            db.session.commit()  # Commit first to get patient.id

            # Get appointment date and time parts from form
            appointment_day = request.form['appointment_day']

            # Build appointment time string from dropdowns: hour, minute, am/pm
            hour = request.form['hour']
            minute = request.form['minute']
            ampm = request.form['ampm']
            appointment_time = f"{hour}:{minute} {ampm}"

            # Create appointment
            appointment = Appointment(
                patient_id=new_patient.id,
                doctor_id=int(request.form['doctor_id']),
                date=appointment_day,
                time=appointment_time
            )
            db.session.add(appointment)
            db.session.commit()

            flash("Patient added and appointment booked successfully.", "success")
            return redirect(url_for('dashboard'))

        except Exception as e:
            db.session.rollback()
            flash(f"Error adding patient: {str(e)}", "danger")
            return redirect(url_for('add_patient'))

    return render_template('add_patient.html', doctors=doctors)

@app.route('/view_patient/<int:patient_id>')
@login_required
def view_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    appointment = Appointment.query.filter_by(patient_id=patient.id).first()
    doctor = None
    if appointment:
        doctor = Doctor.query.get(appointment.doctor_id)
    return render_template('view_patient.html', patient=patient, appointment=appointment, doctor=doctor)

@app.route('/update_patient/<int:patient_id>', methods=['GET', 'POST'])
@login_required
def update_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    doctors = Doctor.query.all()
    appointment = Appointment.query.filter_by(patient_id=patient.id).first()

    if request.method == 'POST':
        try:
            patient.name = request.form['name']
            patient.age = int(request.form['age'])
            patient.gender = request.form['gender']
            patient.contact = request.form['contact']
            patient.visit_date = request.form['visit_date']
            patient.disease = request.form['disease']

            if appointment:
                appointment.date = request.form.get('appointment_date', appointment.date)

                # Build appointment time string if time parts provided, else keep old
                hour = request.form.get('hour')
                minute = request.form.get('minute')
                ampm = request.form.get('ampm')
                if hour and minute and ampm:
                    appointment.time = f"{hour}:{minute} {ampm}"
                else:
                    appointment.time = request.form.get('appointment_time', appointment.time)

            db.session.commit()
            flash("Patient and appointment updated successfully.", "success")
            return redirect(url_for('view_patient', patient_id=patient.id))

        except Exception as e:
            db.session.rollback()
            flash(f"Error updating patient: {str(e)}", "danger")
            return redirect(url_for('update_patient', patient_id=patient.id))

    return render_template('update_patient.html', patient=patient, appointment=appointment, doctors=doctors)

@app.route('/delete_patient/<int:patient_id>', methods=['POST'])
@login_required
def delete_patient(patient_id):
    patient = Patient.query.get_or_404(patient_id)
    try:
        db.session.delete(patient)
        db.session.commit()
        flash("Patient and related appointments deleted successfully.", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Error deleting patient: {str(e)}", "danger")
    return redirect(url_for('dashboard'))

@app.route('/search_patient', methods=['GET', 'POST'])
@login_required
def search_patient():
    patients = []
    if request.method == 'POST':
        query = request.form['search_query']
        patients = Patient.query.filter(
            (Patient.name.contains(query)) |
            (Patient.disease.contains(query))
        ).all()
    return render_template('search_patient.html', patients=patients)

# ----------------------- Doctor Routes -----------------------

@app.route('/add_doctor', methods=['GET', 'POST'])
@login_required
def add_doctor():
    if request.method == 'POST':
        try:
            new_doctor = Doctor(
                name=request.form['name'],
                age=int(request.form['age']),
                gender=request.form['gender'],
                specialization=request.form['specialization'],
                qualification=request.form['qualification'],
                phone=request.form['phone'],
                email=request.form['email'],
                experience=request.form['experience'],
                available_days=request.form['available_days'],
                available_time=request.form['available_time']
            )
            db.session.add(new_doctor)
            db.session.commit()
            flash("Doctor added successfully.", "success")
            return redirect(url_for('dashboard'))

        except Exception as e:
            db.session.rollback()
            flash(f"Error adding doctor: {str(e)}", "danger")

    return render_template('add_doctor.html')

@app.route('/view_doctor/<int:doctor_id>')
@login_required
def view_doctor(doctor_id):
    doctor = Doctor.query.get_or_404(doctor_id)
    return render_template('view_doctor.html', doctor=doctor)

@app.route('/update_doctor/<int:doctor_id>', methods=['GET', 'POST'])
@login_required
def update_doctor(doctor_id):
    doctor = Doctor.query.get_or_404(doctor_id)

    if request.method == 'POST':
        try:
            doctor.name = request.form['name']
            doctor.age = int(request.form['age'])
            doctor.gender = request.form['gender']
            doctor.specialization = request.form['specialization']
            doctor.qualification = request.form['qualification']
            doctor.phone = request.form['phone']
            doctor.email = request.form['email']
            doctor.experience = request.form['experience']
            doctor.available_days = request.form['available_days']
            doctor.available_time = request.form['available_time']

            db.session.commit()
            flash("Doctor updated successfully.", "success")
            return redirect(url_for('view_doctor', doctor_id=doctor.id))

        except Exception as e:
            db.session.rollback()
            flash(f"Error updating doctor: {str(e)}", "danger")
            return redirect(url_for('update_doctor', doctor_id=doctor.id))

    return render_template('update_doctor.html', doctor=doctor)

@app.route('/delete_doctor/<int:doctor_id>', methods=['POST'])
@login_required
def delete_doctor(doctor_id):
    doctor = Doctor.query.get_or_404(doctor_id)
    try:
        db.session.delete(doctor)
        db.session.commit()
        flash("Doctor deleted successfully.", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Error deleting doctor: {str(e)}", "danger")
    return redirect(url_for('dashboard'))

# ----------------------- Run App -----------------------

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)
